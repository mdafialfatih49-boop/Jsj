package com.dafi.mobfusion;

import java.util.UUID;
import java.util.List;

import net.minecraft.entity.EntityGroup;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.math.Box;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.entity.player.PlayerEntity;

public final class FusionHandler {
    private static final String TARGET_UUID = "MobFusionTargetUUID";
    private static final String TARGET_DIMENSION = "MobFusionTargetDimension";
    private static final String CORE_TAG = "mobfusion_core";
    private static final String PART_TAG = "mobfusion_part";
    private static final int LONG_EFFECT = 1_000_000;

    private FusionHandler() {
    }

    public static void handle(PlayerEntity player, MobEntity clicked, ItemStack orb) {
        if (!(player.getWorld() instanceof ServerWorld world)) {
            return;
        }

        NbtCompound data = orb.getOrCreateNbt();
        String currentDimension = world.getRegistryKey().getValue().toString();

        if (!data.contains(TARGET_UUID)) {
            if (isAlreadyFused(clicked)) {
                player.sendMessage(Text.translatable("message.mobfusion.already_fused"), true);
                return;
            }

            data.putString(TARGET_UUID, clicked.getUuidAsString());
            data.putString(TARGET_DIMENSION, currentDimension);
            player.sendMessage(Text.translatable("message.mobfusion.first_selected", clicked.getDisplayName()), true);
            world.playSound(null, clicked.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                    SoundCategory.PLAYERS, 0.8F, 1.35F);
            return;
        }

        if (!currentDimension.equals(data.getString(TARGET_DIMENSION))) {
            clearSelection(data);
            player.sendMessage(Text.translatable("message.mobfusion.wrong_dimension"), true);
            return;
        }

        UUID firstUuid;
        try {
            firstUuid = UUID.fromString(data.getString(TARGET_UUID));
        } catch (IllegalArgumentException exception) {
            clearSelection(data);
            player.sendMessage(Text.translatable("message.mobfusion.selection_lost"), true);
            return;
        }

        if (!(world.getEntity(firstUuid) instanceof MobEntity first) || !first.isAlive()) {
            clearSelection(data);
            player.sendMessage(Text.translatable("message.mobfusion.selection_lost"), true);
            return;
        }

        if (first == clicked) {
            clearSelection(data);
            player.sendMessage(Text.translatable("message.mobfusion.same_mob"), true);
            return;
        }

        if (isAlreadyFused(first) || isAlreadyFused(clicked)) {
            clearSelection(data);
            player.sendMessage(Text.translatable("message.mobfusion.already_fused"), true);
            return;
        }

        if (first.hasPassengers() || clicked.hasVehicle()) {
            clearSelection(data);
            player.sendMessage(Text.translatable("message.mobfusion.cannot_mount"), true);
            return;
        }

        float combinedHealth = first.getHealth() + clicked.getHealth();

        // The second mob becomes the visible passenger. The first mob remains the controller.
        // Do this before changing attributes so a refused mount cannot leave partial stat changes.
        if (!clicked.startRiding(first, true)) {
            clearSelection(data);
            player.sendMessage(Text.translatable("message.mobfusion.mount_failed"), true);
            return;
        }

        combineAttribute(first, clicked, EntityAttributes.GENERIC_MAX_HEALTH, 1024.0D, true);
        combineAttribute(first, clicked, EntityAttributes.GENERIC_ATTACK_DAMAGE, 100.0D, true);
        combineAttribute(first, clicked, EntityAttributes.GENERIC_ARMOR, 30.0D, true);
        combineAttribute(first, clicked, EntityAttributes.GENERIC_ARMOR_TOUGHNESS, 20.0D, true);
        combineAttribute(first, clicked, EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0D, true);
        combineAttribute(first, clicked, EntityAttributes.GENERIC_MOVEMENT_SPEED, 1.0D, false);

        clicked.setAiDisabled(true);
        clicked.setInvulnerable(true);
        clicked.setPersistent();
        clicked.addCommandTag(PART_TAG);

        first.setPersistent();
        first.addCommandTag(CORE_TAG);
        first.setHealth(Math.min(first.getMaxHealth(), combinedHealth));
        applyTraits(first, clicked);

        world.playSound(null, first.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE,
                SoundCategory.PLAYERS, 1.0F, 1.15F);
        world.spawnParticles(net.minecraft.particle.ParticleTypes.PORTAL,
                first.getX(), first.getY() + 0.8D, first.getZ(),
                36, 0.45D, 0.65D, 0.45D, 0.08D);

        player.sendMessage(Text.translatable("message.mobfusion.success",
                first.getDisplayName(), clicked.getDisplayName()), true);
        clearSelection(data);
    }

    private static boolean isAlreadyFused(MobEntity mob) {
        return mob.getCommandTags().contains(CORE_TAG)
                || mob.getCommandTags().contains(PART_TAG)
                || mob.hasPassengers()
                || mob.hasVehicle();
    }

    private static void clearSelection(NbtCompound data) {
        data.remove(TARGET_UUID);
        data.remove(TARGET_DIMENSION);
    }

    /**
     * Restores a fused passenger if its controller no longer exists, and clears stale core tags.
     * Runs periodically so it does not scan loaded mobs on every game tick.
     */
    public static void cleanupOrphans(ServerWorld world) {
        if (world.getTime() % 20L != 0L) {
            return;
        }

        Box loadedWorldSearch = new Box(-30_000_000.0D, world.getBottomY(), -30_000_000.0D,
                30_000_000.0D, world.getTopY(), 30_000_000.0D);
        List<MobEntity> markedMobs = world.getEntitiesByType(
                TypeFilter.instanceOf(MobEntity.class),
                loadedWorldSearch,
                mob -> mob.getCommandTags().contains(PART_TAG)
                        || mob.getCommandTags().contains(CORE_TAG)
        );

        for (MobEntity mob : markedMobs) {
            if (mob.getCommandTags().contains(PART_TAG)) {
                Entity vehicle = mob.getVehicle();
                if (!(vehicle instanceof MobEntity parent)
                        || !parent.getCommandTags().contains(CORE_TAG)) {
                    mob.stopRiding();
                    mob.setAiDisabled(false);
                    mob.setInvulnerable(false);
                    mob.removeCommandTag(PART_TAG);
                }
            }

            if (mob.getCommandTags().contains(CORE_TAG)) {
                boolean hasFusionPart = mob.getPassengers().stream()
                        .anyMatch(passenger -> passenger.getCommandTags().contains(PART_TAG));
                if (!hasFusionPart) {
                    mob.removeCommandTag(CORE_TAG);
                }
            }
        }
    }

    private static void combineAttribute(MobEntity host, MobEntity donor,
                                         EntityAttribute attribute, double cap, boolean add) {
        EntityAttributeInstance hostAttribute = host.getAttributeInstance(attribute);
        EntityAttributeInstance donorAttribute = donor.getAttributeInstance(attribute);
        if (hostAttribute == null || donorAttribute == null) {
            return;
        }

        double firstValue = hostAttribute.getBaseValue();
        double secondValue = donorAttribute.getBaseValue();
        double combined = add ? firstValue + secondValue : Math.max(firstValue, secondValue);
        hostAttribute.setBaseValue(Math.max(0.0D, Math.min(cap, combined)));
    }

    private static void applyTraits(MobEntity host, MobEntity donor) {
        if (donor.isFireImmune()) {
            host.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE,
                    LONG_EFFECT, 0, false, false, true));
        }

        EntityGroup group = donor.getGroup();
        if (group == EntityGroup.AQUATIC) {
            host.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING,
                    LONG_EFFECT, 0, false, false, true));
            host.addStatusEffect(new StatusEffectInstance(StatusEffects.DOLPHINS_GRACE,
                    LONG_EFFECT, 0, false, false, true));
        } else if (group == EntityGroup.UNDEAD) {
            host.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH,
                    LONG_EFFECT, 0, false, false, true));
        } else if (group == EntityGroup.ARTHROPOD) {
            host.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST,
                    LONG_EFFECT, 0, false, false, true));
        } else if (group == EntityGroup.ILLAGER) {
            host.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,
                    LONG_EFFECT, 0, false, false, true));
        }
    }
}
