package com.dafi.mobfusion;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;

public class MobFusionMod implements ModInitializer {
    public static final String MOD_ID = "mobfusion";

    @Override
    public void onInitialize() {
        ModItems.register();
        ServerTickEvents.END_WORLD_TICK.register(FusionHandler::cleanupOrphans);

        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            ItemStack heldStack = player.getStackInHand(hand);
            if (!heldStack.isOf(ModItems.FUSION_ORB)) {
                return ActionResult.PASS;
            }

            // The client only predicts the interaction. All entity changes happen on the server.
            if (world.isClient) {
                return ActionResult.SUCCESS;
            }

            if (!(entity instanceof MobEntity mob) || !mob.isAlive()) {
                player.sendMessage(Text.translatable("message.mobfusion.not_a_mob"), true);
                return ActionResult.FAIL;
            }

            FusionHandler.handle(player, mob, heldStack);
            return ActionResult.SUCCESS;
        });
    }
}
