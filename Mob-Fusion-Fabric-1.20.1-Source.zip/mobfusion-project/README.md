# Mob Fusion — Minecraft Java 1.20.1 (Fabric)

Mod ini menambahkan **Orb Fusi Mob**. Gunakan orb pada dua mob untuk menjadikan mob kedua penumpang visual mob pertama. Mob pertama menjadi pengendali; mob kedua tetap terlihat, tetapi AI-nya dinonaktifkan dan ia dilindungi agar tidak menerima damage secara terpisah.

## Fitur

- Memadukan dua `MobEntity` dari Minecraft atau mod lain yang mengizinkan hubungan penumpang.
- Statistik dasar digabung: maksimum health, attack damage, armor, armor toughness, dan knockback resistance.
- Kecepatan gerak memakai nilai yang lebih tinggi dari kedua mob.
- Sifat tambahan berdasarkan mob kedua: tahan api, kemampuan bernapas di air, kekuatan, lompatan, atau resistance.
- Mendukung mob dengan model dan animasi aslinya karena model kedua tidak diganti.
- Tidak mengubah pemain menjadi target fusi.

## Cara menggunakan

1. Pasang Minecraft **Java 1.20.1**, Fabric Loader, dan Fabric API yang cocok.
2. Masukkan `mob-fusion-1.0.0.jar` ke folder `mods`.
3. Ambil Orb Fusi Mob dari tab **Tools** di Creative Inventory, atau buat di meja crafting dengan resep 4 Amethyst Shard + 4 Ender Pearl + 1 Ender Eye.
4. Klik kanan mob pertama dengan Orb Fusi Mob.
5. Klik kanan mob kedua. Kedua model akan terlihat sebagai satu pasangan fusi.

Orb yang sama bisa digunakan lagi setelah satu fusi selesai. Alternatif command: `/give @p mobfusion:fusion_orb`. Jika mob pertama mati, mob kedua dapat terlepas sebagai mob tersendiri.

## Cara build lewat GitHub (bisa dari Android)

1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP source ini ke repository. Pastikan folder `.github/workflows/build.yml` ikut ter-upload.
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build Mob Fusion**, lalu tekan **Run workflow**. Workflow juga berjalan otomatis setelah push.
5. Setelah selesai, buka hasil run dan unduh artifact bernama `mob-fusion-minecraft-1.20.1-fabric`.
6. Di dalam artifact, ambil `mob-fusion-1.0.0.jar` (bukan file `-sources.jar`).
7. Pasang Fabric API yang sesuai, lalu taruh JAR Mob Fusion ke folder `mods`.

## Build lokal

Memerlukan JDK 17 dan Gradle 8.6:

```bash
gradle --no-daemon build
```

JAR hasil build berada di `build/libs/`.

## Batasan teknis yang perlu diketahui

Fusi universal untuk semua kombinasi mob tidak bisa menghasilkan satu model 3D baru yang benar-benar menyatukan anatomi dua mob secara otomatis tanpa membuat model dan tekstur khusus untuk setiap pasangan. Mod ini memakai sistem mount/passenger: dua model asli tetap terlihat dan bergerak sebagai satu unit. Ini juga berarti secara internal game tetap menyimpan dua entity yang saling terhubung, bukan satu entity baru.

Kebanyakan mob vanilla dan banyak mob modded yang merupakan turunan `MobEntity` dapat dipakai. Mob modded yang melarang penumpang atau memiliki sistem mount khusus bisa menolak fusi. Mob yang sudah membawa/ditunggangi entity lain juga ditolak agar hubungan entity tidak rusak.

## Versi

- Minecraft: 1.20.1
- Loader: Fabric
- Java: 17
- Fabric API: 0.92.2+1.20.1
- Mod version: 1.0.0
